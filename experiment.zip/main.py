import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle
import random
import math
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import heapq

class RobotRole(Enum):
    """机器人角色枚举"""
    REGULAR_EXPLORER = "regular_explorer"
    LEADER = "leader"
    PRIMARY_SENTRY = "primary_sentry"
    SECONDARY_SENTRY = "secondary_sentry"
    MEMBER = "member"
    OBSTACLE_SENTRY = "obstacle_sentry"

class RobotState(Enum):
    """机器人状态枚举"""
    EXPLORING = "exploring"
    MOVING_TO_SENTRY = "moving_to_sentry"
    VISITING_SENTRIES = "visiting_sentries"
    RENDEZVOUS = "rendezvous"
    STATIONARY = "stationary"

@dataclass
class Position:
    """位置类"""
    x: float
    y: float
    
    def distance_to(self, other: 'Position') -> float:
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
    
    def __add__(self, other):
        return Position(self.x + other.x, self.y + other.y)
    
    def __sub__(self, other):
        return Position(self.x - other.x, self.y - other.y)
    
    def __mul__(self, scalar):
        return Position(self.x * scalar, self.y * scalar)

@dataclass
class Obstacle:
    """障碍物类"""
    vertices: List[Position]
    sentry_position: Optional[Position] = None
    has_sentry: bool = False

class Robot:
    """机器人类"""
    
    def __init__(self, robot_id: int, initial_position: Position, communication_range: float):
        self.id = robot_id
        self.position = initial_position
        self.initial_position = initial_position
        self.communication_range = communication_range
        self.role = RobotRole.REGULAR_EXPLORER
        self.state = RobotState.EXPLORING
        self.current_round = 1
        self.target_position = None
        self.speed = 1.0
        
        # 领导者相关属性
        self.sentries: List['Robot'] = []  # 哨兵列表
        self.members: List['Robot'] = []   # 成员列表
        self.leader_id: Optional[int] = None  # 所属领导者ID
        self.known_robots: Dict[int, Position] = {}  # 已知机器人位置
        self.other_leaders_info: Dict[int, Dict] = {}  # 其他领导者信息
        
        # 探索相关属性
        self.exploration_angle = 0.0
        self.circular_search_radius = 0.0
        self.obstacle_boundary_path: List[Position] = []
        self.obstacle_boundary_index = 0
        
        # 访问路径相关
        self.visiting_path: List[Position] = []
        self.visiting_index = 0
        
    def can_communicate_with(self, other: 'Robot') -> bool:
        """检查是否能与另一个机器人通信"""
        return self.position.distance_to(other.position) <= self.communication_range
    
    def move_towards(self, target: Position, dt: float = 0.1):
        """向目标位置移动"""
        if self.target_position is None:
            return
            
        direction = target - self.position
        distance = direction.distance_to(Position(0, 0))
        
        if distance < self.speed * dt:
            self.position = target
            self.target_position = None
        else:
            # 标准化方向向量并移动
            direction_normalized = Position(
                direction.x / distance,
                direction.y / distance
            )
            self.position = self.position + direction_normalized * self.speed * dt
    
    def update_exploration(self, dt: float):
        """更新探索行为"""
        if self.role != RobotRole.REGULAR_EXPLORER and self.role != RobotRole.LEADER:
            return
            
        if self.state == RobotState.EXPLORING:
            # 检查是否在沿障碍物边界移动
            if self.obstacle_boundary_path:
                self.update_obstacle_boundary_movement(dt)
            else:
                # 第一阶段：沿y轴正方向移动2R距离
                if self.position.y < self.initial_position.y + 2 * self.communication_range:
                    self.target_position = Position(
                        self.initial_position.x,
                        self.initial_position.y + 2 * self.communication_range
                    )
                    self.move_towards(self.target_position, dt)
                else:
                    # 第二阶段：圆形搜索
                    self.perform_circular_search(dt)
    
    def perform_circular_search(self, dt: float):
        """执行圆形搜索"""
        radius = 2 * self.current_round * self.communication_range
        angle_speed = self.speed / radius if radius > 0 else 0
        
        self.exploration_angle += angle_speed * dt
        
        # 计算圆形路径上的位置
        new_x = self.initial_position.x + radius * math.cos(self.exploration_angle)
        new_y = self.initial_position.y + radius * math.sin(self.exploration_angle)
        
        self.position = Position(new_x, new_y)
        
        # 检查是否完成一圈
        if self.exploration_angle >= 2 * math.pi:
            self.exploration_angle = 0
            self.current_round += 1
    
    def handle_encounter(self, other: 'Robot'):
        """处理与另一个机器人的相遇"""
        if not self.can_communicate_with(other):
            return
            
        # 根据算法规则处理相遇
        if (self.role == RobotRole.REGULAR_EXPLORER and 
            other.role == RobotRole.REGULAR_EXPLORER):
            self.handle_explorer_meeting(other)
        elif (self.role == RobotRole.REGULAR_EXPLORER and 
              other.role == RobotRole.LEADER):
            self.become_secondary_sentry(other)
        elif (self.role == RobotRole.REGULAR_EXPLORER and 
              other.role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY]):
            self.join_sentry_group(other)
        elif (self.role == RobotRole.PRIMARY_SENTRY and 
              other.role == RobotRole.LEADER):
            other.record_sentry_position(self)
        elif (self.role == RobotRole.LEADER and 
              other.role == RobotRole.LEADER):
            self.exchange_leader_info(other)
    
    def handle_obstacle_encounter(self, obstacle: 'Obstacle'):
        """处理与障碍物的相遇"""
        if self.role != RobotRole.REGULAR_EXPLORER and self.role != RobotRole.LEADER:
            return
            
        # 开始沿障碍物边界移动
        self.obstacle_boundary_path = self.calculate_obstacle_boundary_path(obstacle)
        self.obstacle_boundary_index = 0
        self.state = RobotState.EXPLORING  # 继续探索状态，但沿边界移动
    
    def calculate_obstacle_boundary_path(self, obstacle: 'Obstacle') -> List[Position]:
        """计算障碍物边界路径"""
        # 简化版本：沿障碍物顶点移动
        return obstacle.vertices.copy()
    
    def update_obstacle_boundary_movement(self, dt: float):
        """更新沿障碍物边界的移动"""
        if not self.obstacle_boundary_path:
            return
            
        if self.obstacle_boundary_index < len(self.obstacle_boundary_path):
            target = self.obstacle_boundary_path[self.obstacle_boundary_index]
            self.move_towards(target, dt)
            
            if self.position.distance_to(target) < 1.0:
                self.obstacle_boundary_index += 1
                
                # 检查是否完成一圈
                if self.obstacle_boundary_index >= len(self.obstacle_boundary_path):
                    self.handle_obstacle_circuit_complete()
        else:
            self.obstacle_boundary_path = []
            self.obstacle_boundary_index = 0
    
    def handle_obstacle_circuit_complete(self):
        """处理完成障碍物一圈后的逻辑"""
        # 根据算法规则处理
        if self.role == RobotRole.REGULAR_EXPLORER:
            # 检查是否有障碍物哨兵
            # 这里需要全局状态来检查
            pass
        elif self.role == RobotRole.LEADER:
            # 领导者遇到障碍物哨兵的处理
            pass
    
    def handle_explorer_meeting(self, other: 'Robot'):
        """处理两个探索者相遇"""
        if self.current_round > other.current_round:
            # 当前机器人成为领导者
            self.become_leader()
            self.record_robot_position(other)
            other.become_primary_sentry(self)
        elif other.current_round > self.current_round:
            # 另一个机器人成为领导者
            other.become_leader()
            other.record_robot_position(self)
            self.become_primary_sentry(other)
    
    def become_leader(self):
        """成为领导者"""
        self.role = RobotRole.LEADER
        self.state = RobotState.EXPLORING
        self.sentries = []
        self.members = []
    
    def become_primary_sentry(self, leader: 'Robot'):
        """成为主要哨兵"""
        self.role = RobotRole.PRIMARY_SENTRY
        self.state = RobotState.STATIONARY
        self.leader_id = leader.id
        leader.sentries.append(self)
    
    def become_secondary_sentry(self, leader: 'Robot'):
        """成为次要哨兵"""
        self.role = RobotRole.SECONDARY_SENTRY
        self.state = RobotState.STATIONARY
        self.leader_id = leader.id
        leader.sentries.append(self)
    
    def join_sentry_group(self, sentry: 'Robot'):
        """加入哨兵组"""
        self.role = RobotRole.MEMBER
        self.state = RobotState.STATIONARY
        self.leader_id = sentry.leader_id
        if sentry.leader_id:
            # 找到对应的领导者并添加到成员列表
            pass  # 这里需要全局机器人管理器来找到领导者
    
    def record_robot_position(self, robot: 'Robot'):
        """记录机器人位置"""
        self.known_robots[robot.id] = robot.position
    
    def record_sentry_position(self, sentry: 'Robot'):
        """记录哨兵位置"""
        self.known_robots[sentry.id] = sentry.position
    
    def exchange_leader_info(self, other_leader: 'Robot'):
        """交换领导者信息"""
        # 交换初始位置和哨兵信息
        self.other_leaders_info[other_leader.id] = {
            'initial_position': other_leader.initial_position,
            'sentries': [s.id for s in other_leader.sentries]
        }
        other_leader.other_leaders_info[self.id] = {
            'initial_position': self.initial_position,
            'sentries': [s.id for s in self.sentries]
        }

class RobotSimulation:
    """机器人模拟主类"""
    
    def __init__(self, num_robots: int = 5, communication_range: float = 10.0, 
                 world_size: Tuple[float, float] = (200, 200), 
                 robot_spawn_range: Tuple[float, float] = None):
        self.robots: List[Robot] = []
        self.obstacles: List[Obstacle] = []
        self.communication_range = communication_range
        self.world_size = world_size
        self.robot_spawn_range = robot_spawn_range or (50, world_size[0] - 50)
        self.simulation_time = 0.0
        self.rendezvous_location: Optional[Position] = None
        self.rendezvous_phase = False
        self.rendezvous_time: Optional[float] = None  # 交会完成时间
        self.experiment_id: Optional[str] = None  # 实验ID
        
        # 初始化机器人
        self.initialize_robots(num_robots)
        
        # 创建一些障碍物
        self.create_obstacles()
    
    def initialize_robots(self, num_robots: int):
        """初始化机器人"""
        for i in range(num_robots):
            # 在指定范围内随机生成初始位置
            x = random.uniform(self.robot_spawn_range[0], self.robot_spawn_range[1])
            y = random.uniform(self.robot_spawn_range[0], self.robot_spawn_range[1])
            position = Position(x, y)
            
            robot = Robot(i, position, self.communication_range)
            self.robots.append(robot)
    
    def create_obstacles(self):
        """创建障碍物"""
        # 创建几个矩形障碍物
        obstacles_data = [
            [(50, 50), (80, 50), (80, 80), (50, 80)],
            [(120, 120), (150, 120), (150, 150), (120, 150)],
            [(30, 120), (60, 120), (60, 150), (30, 150)]
        ]
        
        for vertices_data in obstacles_data:
            vertices = [Position(x, y) for x, y in vertices_data]
            obstacle = Obstacle(vertices)
            self.obstacles.append(obstacle)
    
    def update_simulation(self, dt: float = 0.1):
        """更新模拟"""
        self.simulation_time += dt
        
        # 更新每个机器人的状态
        for robot in self.robots:
            if robot.state == RobotState.EXPLORING:
                robot.update_exploration(dt)
            elif robot.state == RobotState.MOVING_TO_SENTRY:
                # 移动到哨兵位置
                pass
            elif robot.state == RobotState.VISITING_SENTRIES:
                # 访问哨兵
                self.update_leader_visiting(robot, dt)
            elif robot.state == RobotState.RENDEZVOUS:
                # 交会阶段
                self.update_rendezvous_movement(robot, dt)
        
        # 检查机器人相遇
        self.check_robot_encounters()
        
        # 检查障碍物碰撞
        self.check_obstacle_collisions()
        
        # 检查是否进入交会阶段
        if not self.rendezvous_phase:
            self.check_rendezvous_condition()
    
    def check_robot_encounters(self):
        """检查机器人相遇"""
        for i in range(len(self.robots)):
            for j in range(i + 1, len(self.robots)):
                robot1 = self.robots[i]
                robot2 = self.robots[j]
                
                if robot1.can_communicate_with(robot2):
                    robot1.handle_encounter(robot2)
    
    def check_obstacle_collisions(self):
        """检查障碍物碰撞"""
        for robot in self.robots:
            if robot.state == RobotState.EXPLORING:
                for obstacle in self.obstacles:
                    if self.is_robot_colliding_with_obstacle(robot, obstacle):
                        robot.handle_obstacle_encounter(obstacle)
                        break
    
    def is_robot_colliding_with_obstacle(self, robot: Robot, obstacle: Obstacle) -> bool:
        """检查机器人是否与障碍物碰撞"""
        # 简化的点-多边形碰撞检测
        robot_pos = robot.position
        vertices = obstacle.vertices
        
        # 使用射线法检测点是否在多边形内部
        n = len(vertices)
        inside = False
        
        j = n - 1
        for i in range(n):
            if ((vertices[i].y > robot_pos.y) != (vertices[j].y > robot_pos.y)) and \
               (robot_pos.x < (vertices[j].x - vertices[i].x) * (robot_pos.y - vertices[i].y) / 
                (vertices[j].y - vertices[i].y) + vertices[i].x):
                inside = not inside
            j = i
        
        return inside
    
    def update_leader_visiting(self, leader: Robot, dt: float):
        """更新领导者访问哨兵"""
        if not leader.visiting_path:
            # 计算TSP路径
            leader.visiting_path = self.calculate_tsp_path(leader)
            leader.visiting_index = 0
        
        if leader.visiting_index < len(leader.visiting_path):
            target = leader.visiting_path[leader.visiting_index]
            leader.move_towards(target, dt)
            
            if leader.position.distance_to(target) < 1.0:
                leader.visiting_index += 1
        else:
            # 访问完成，检查交会条件
            leader.state = RobotState.EXPLORING
    
    def calculate_tsp_path(self, leader: Robot) -> List[Position]:
        """计算TSP路径（使用最近邻算法）"""
        # 收集所有需要访问的哨兵位置
        positions = []
        for sentry in leader.sentries:
            positions.append(sentry.position)
        
        # 添加其他领导者的主要哨兵位置
        for other_leader_id, info in leader.other_leaders_info.items():
            # 这里需要从全局状态获取其他领导者的哨兵位置
            pass
        
        # 简单的最近邻算法
        if not positions:
            return []
        
        path = []
        unvisited = positions.copy()
        current_pos = leader.position
        
        while unvisited:
            nearest = min(unvisited, key=lambda p: current_pos.distance_to(p))
            path.append(nearest)
            unvisited.remove(nearest)
            current_pos = nearest
        
        return path
    
    def check_rendezvous_condition(self):
        """检查交会条件"""
        # 检查是否有领导者满足交会条件
        for leader in self.robots:
            if leader.role == RobotRole.LEADER:
                total_count = (len(leader.members) + 
                              len([s for s in leader.sentries if s.role == RobotRole.SECONDARY_SENTRY]) +
                              2 * len([s for s in leader.sentries if s.role == RobotRole.PRIMARY_SENTRY]))
                
                if total_count >= len(self.robots):
                    self.start_rendezvous_phase()
                    break
    
    def start_rendezvous_phase(self):
        """开始交会阶段"""
        self.rendezvous_phase = True
        self.rendezvous_time = self.simulation_time  # 记录交会开始时间
        
        # 找到最远的两个主要哨兵
        primary_sentries = []
        for robot in self.robots:
            if robot.role == RobotRole.PRIMARY_SENTRY:
                primary_sentries.append(robot)
        
        if len(primary_sentries) >= 2:
            # 计算最远距离的两个哨兵
            max_distance = 0
            sentry1, sentry2 = None, None
            
            for i in range(len(primary_sentries)):
                for j in range(i + 1, len(primary_sentries)):
                    distance = primary_sentries[i].position.distance_to(primary_sentries[j].position)
                    if distance > max_distance:
                        max_distance = distance
                        sentry1, sentry2 = primary_sentries[i], primary_sentries[j]
            
            if sentry1 and sentry2:
                # 计算交会位置（两个哨兵的中点）
                self.rendezvous_location = Position(
                    (sentry1.position.x + sentry2.position.x) / 2,
                    (sentry1.position.y + sentry2.position.y) / 2
                )
                
                # 设置所有机器人进入交会状态
                for robot in self.robots:
                    robot.state = RobotState.RENDEZVOUS
                    robot.target_position = self.rendezvous_location
    
    def update_rendezvous_movement(self, robot: Robot, dt: float):
        """更新交会移动"""
        if self.rendezvous_location:
            robot.move_towards(self.rendezvous_location, dt)
    
    def visualize(self, ax):
        """可视化当前状态"""
        ax.clear()
        ax.set_xlim(0, self.world_size[0])
        ax.set_ylim(0, self.world_size[1])
        ax.set_aspect('equal')
        
        # 绘制障碍物
        for obstacle in self.obstacles:
            vertices = [(v.x, v.y) for v in obstacle.vertices]
            vertices.append(vertices[0])  # 闭合多边形
            x_coords, y_coords = zip(*vertices)
            ax.plot(x_coords, y_coords, 'k-', linewidth=2)
            ax.fill(x_coords, y_coords, 'gray', alpha=0.3)
        
        # 绘制机器人
        colors = {
            RobotRole.REGULAR_EXPLORER: 'blue',
            RobotRole.LEADER: 'red',
            RobotRole.PRIMARY_SENTRY: 'green',
            RobotRole.SECONDARY_SENTRY: 'orange',
            RobotRole.MEMBER: 'purple',
            RobotRole.OBSTACLE_SENTRY: 'brown'
        }
        
        role_labels = {
            RobotRole.REGULAR_EXPLORER: 'E',
            RobotRole.LEADER: 'L',
            RobotRole.PRIMARY_SENTRY: 'PS',
            RobotRole.SECONDARY_SENTRY: 'SS',
            RobotRole.MEMBER: 'M',
            RobotRole.OBSTACLE_SENTRY: 'OS'
        }
        
        for robot in self.robots:
            color = colors.get(robot.role, 'black')
            marker_size = 120 if robot.role == RobotRole.LEADER else 80
            ax.scatter(robot.position.x, robot.position.y, c=color, s=marker_size, 
                      edgecolors='black', linewidth=1, alpha=0.8)
            
            # 添加机器人ID和角色标签
            label = f'R{robot.id}({role_labels.get(robot.role, "?")})'
            ax.annotate(label, (robot.position.x, robot.position.y), 
                       xytext=(5, 5), textcoords='offset points', fontsize=7,
                       bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.7))
            
            # 绘制通信范围（只对探索者和领导者显示）
            if robot.role in [RobotRole.REGULAR_EXPLORER, RobotRole.LEADER]:
                circle = Circle((robot.position.x, robot.position.y), 
                              robot.communication_range, 
                              fill=False, linestyle='--', alpha=0.2, color=color)
                ax.add_patch(circle)
        
        # 绘制交会位置
        if self.rendezvous_location:
            ax.scatter(self.rendezvous_location.x, self.rendezvous_location.y, 
                      c='red', s=200, marker='*', label='Rendezvous Point')
        
        ax.set_title(f'Robot Rendezvous Simulation (t={self.simulation_time:.1f})')
        ax.legend()
        ax.grid(True, alpha=0.3)

def run_simulation():
    """运行模拟"""
    # 创建模拟
    sim = RobotSimulation(num_robots=8, communication_range=15.0, world_size=(200, 200))
    
    # 设置matplotlib
    fig, ax = plt.subplots(figsize=(12, 10))
    
    def animate(frame):
        sim.update_simulation(dt=0.5)
        sim.visualize(ax)
        return []
    
    # 运行动画
    anim = animation.FuncAnimation(fig, animate, frames=1000, 
                                 interval=100, blit=False, repeat=True)
    
    plt.tight_layout()
    plt.show()
    
    return sim

def run_static_test():
    """运行静态测试（不显示动画）"""
    print("开始机器人交会算法测试...")
    
    # 创建模拟
    sim = RobotSimulation(num_robots=6, communication_range=20.0, world_size=(150, 150))
    
    # 运行固定步数的模拟
    for step in range(200):
        sim.update_simulation(dt=0.5)
        
        # 每50步打印一次状态
        if step % 50 == 0:
            print(f"\n步骤 {step}:")
            leaders = [r for r in sim.robots if r.role == RobotRole.LEADER]
            sentries = [r for r in sim.robots if r.role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY]]
            members = [r for r in sim.robots if r.role == RobotRole.MEMBER]
            explorers = [r for r in sim.robots if r.role == RobotRole.REGULAR_EXPLORER]
            
            print(f"  领导者数量: {len(leaders)}")
            print(f"  哨兵数量: {len(sentries)}")
            print(f"  成员数量: {len(members)}")
            print(f"  探索者数量: {len(explorers)}")
            
            if sim.rendezvous_phase:
                print(f"  交会阶段已开始，交会位置: ({sim.rendezvous_location.x:.1f}, {sim.rendezvous_location.y:.1f})")
    
    print("\n测试完成！")
    return sim

if __name__ == "__main__":
    print("机器人交会算法模拟开始...")
    print("选择运行模式:")
    print("1. 动画可视化模式 (推荐)")
    print("2. 静态测试模式")
    
    try:
        choice = input("请输入选择 (1 或 2): ").strip()
        
        if choice == "1":
            print("启动动画可视化...")
            simulation = run_simulation()
        elif choice == "2":
            print("启动静态测试...")
            simulation = run_static_test()
        else:
            print("无效选择，默认启动动画可视化...")
            simulation = run_simulation()
            
        print("模拟完成！")
        
    except KeyboardInterrupt:
        print("\n模拟被用户中断")
    except Exception as e:
        print(f"模拟过程中出现错误: {e}")
        print("尝试运行静态测试模式...")
        simulation = run_static_test()
