#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快速实验脚本 - 简化版实验管理
"""

import random
import time
from datetime import datetime
import csv
import os

from main import RobotSimulation, RobotRole

def quick_experiment(num_robots=6, communication_range=15.0, world_size=(200, 200), 
                    spawn_range=(50, 150), max_time=500.0, time_step=0.5):
    """运行单次快速实验"""
    
    print(f"开始实验: {num_robots}个机器人, 通信范围={communication_range}, 世界大小={world_size}")
    
    # 创建模拟
    sim = RobotSimulation(
        num_robots=num_robots,
        communication_range=communication_range,
        world_size=world_size,
        robot_spawn_range=spawn_range
    )
    
    start_time = time.time()
    step_count = 0
    
    # 运行模拟
    while sim.simulation_time < max_time:
        sim.update_simulation(dt=time_step)
        step_count += 1
        
        # 检查交会完成
        if sim.rendezvous_phase and check_rendezvous_completion(sim):
            break
        
        # 每50步显示进度
        if step_count % 50 == 0:
            leaders = [r for r in sim.robots if r.role == RobotRole.LEADER]
            sentries = [r for r in sim.robots if r.role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY]]
            print(f"  步骤 {step_count}, 时间 {sim.simulation_time:.1f}, 领导者={len(leaders)}, 哨兵={len(sentries)}")
    
    # 计算结果
    actual_time = time.time() - start_time
    success = sim.rendezvous_phase
    rendezvous_time = sim.rendezvous_time if success else None
    
    # 统计角色分布
    role_counts = {}
    for robot in sim.robots:
        role = robot.role.value
        role_counts[role] = role_counts.get(role, 0) + 1
    
    print(f"实验完成: {'成功' if success else '失败'}")
    if rendezvous_time is not None:
        print(f"交会时间: {rendezvous_time:.1f}")
    else:
        print("交会时间: N/A")
    print(f"模拟时间: {sim.simulation_time:.1f}")
    print(f"实际运行时间: {actual_time:.2f}秒")
    print(f"角色分布: {role_counts}")
    
    return {
        'success': success,
        'rendezvous_time': rendezvous_time,
        'simulation_time': sim.simulation_time,
        'actual_time': actual_time,
        'role_counts': role_counts,
        'num_robots': num_robots,
        'communication_range': communication_range,
        'world_size': world_size,
        'spawn_range': spawn_range
    }

def check_rendezvous_completion(sim):
    """检查交会是否完成"""
    if not sim.rendezvous_location:
        return False
    
    threshold = sim.communication_range * 2
    for robot in sim.robots:
        distance = robot.position.distance_to(sim.rendezvous_location)
        if distance > threshold:
            return False
    return True

def run_parameter_sweep():
    """运行参数扫描实验"""
    print("=" * 60)
    print("参数扫描实验")
    print("=" * 60)
    
    # 实验参数
    robot_counts = [4, 6, 8, 10]
    comm_ranges = [10.0, 15.0, 20.0, 25.0]
    
    results = []
    
    for num_robots in robot_counts:
        for comm_range in comm_ranges:
            print(f"\n--- 机器人数量: {num_robots}, 通信范围: {comm_range} ---")
            
            result = quick_experiment(
                num_robots=num_robots,
                communication_range=comm_range,
                world_size=(200, 200),
                spawn_range=(50, 150),
                max_time=500.0
            )
            
            results.append(result)
    
    return results

def run_random_experiments(num_experiments=10):
    """运行随机参数实验"""
    print("=" * 60)
    print(f"随机参数实验 ({num_experiments}次)")
    print("=" * 60)
    
    results = []
    
    for i in range(num_experiments):
        print(f"\n--- 实验 {i+1}/{num_experiments} ---")
        
        # 随机参数
        num_robots = random.randint(4, 10)
        comm_range = random.uniform(10.0, 25.0)
        world_size = (random.randint(150, 250), random.randint(150, 250))
        spawn_range = (world_size[0] * 0.2, world_size[0] * 0.8)
        
        result = quick_experiment(
            num_robots=num_robots,
            communication_range=comm_range,
            world_size=world_size,
            spawn_range=spawn_range,
            max_time=600.0
        )
        
        results.append(result)
    
    return results

def save_results_to_csv(results, filename=None):
    """保存结果到CSV"""
    if not filename:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"quick_experiment_results_{timestamp}.csv"
    
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = [
            'experiment_id', 'success', 'rendezvous_time', 'simulation_time', 'actual_time',
            'num_robots', 'communication_range', 'world_size_x', 'world_size_y',
            'spawn_range_min', 'spawn_range_max', 'leader_count', 'sentry_count', 'member_count'
        ]
        
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for i, result in enumerate(results):
            role_counts = result['role_counts']
            row = {
                'experiment_id': f'exp_{i+1:03d}',
                'success': result['success'],
                'rendezvous_time': result['rendezvous_time'],
                'simulation_time': result['simulation_time'],
                'actual_time': result['actual_time'],
                'num_robots': result['num_robots'],
                'communication_range': result['communication_range'],
                'world_size_x': result['world_size'][0],
                'world_size_y': result['world_size'][1],
                'spawn_range_min': result['spawn_range'][0],
                'spawn_range_max': result['spawn_range'][1],
                'leader_count': role_counts.get('leader', 0),
                'sentry_count': role_counts.get('primary_sentry', 0) + role_counts.get('secondary_sentry', 0),
                'member_count': role_counts.get('member', 0)
            }
            writer.writerow(row)
    
    print(f"结果已保存到: {filename}")
    return filename

def print_summary(results):
    """打印实验总结"""
    if not results:
        print("没有实验结果")
        return
    
    print("\n" + "=" * 60)
    print("实验总结")
    print("=" * 60)
    
    total = len(results)
    successful = sum(1 for r in results if r['success'])
    success_rate = successful / total * 100
    
    print(f"总实验数: {total}")
    print(f"成功实验数: {successful}")
    print(f"成功率: {success_rate:.1f}%")
    
    if successful > 0:
        rendezvous_times = [r['rendezvous_time'] for r in results if r['success'] and r['rendezvous_time']]
        if rendezvous_times:
            avg_time = sum(rendezvous_times) / len(rendezvous_times)
            min_time = min(rendezvous_times)
            max_time = max(rendezvous_times)
            
            print(f"\n交会时间统计:")
            print(f"  平均交会时间: {avg_time:.1f}")
            print(f"  最短交会时间: {min_time:.1f}")
            print(f"  最长交会时间: {max_time:.1f}")
    
    # 参数影响分析
    print(f"\n参数统计:")
    comm_ranges = [r['communication_range'] for r in results]
    robot_counts = [r['num_robots'] for r in results]
    
    print(f"  通信范围: {min(comm_ranges):.1f} - {max(comm_ranges):.1f}")
    print(f"  机器人数量: {min(robot_counts)} - {max(robot_counts)}")

def main():
    """主函数"""
    print("机器人交会算法快速实验工具")
    print("=" * 60)
    
    print("选择实验模式:")
    print("1. 单次实验")
    print("2. 参数扫描实验")
    print("3. 随机参数实验")
    print("4. 自定义实验")
    
    try:
        choice = input("请输入选择 (1-4): ").strip()
        
        if choice == "1":
            # 单次实验
            print("\n单次实验参数:")
            num_robots = int(input("机器人数量 (默认6): ") or "6")
            comm_range = float(input("通信范围 (默认15.0): ") or "15.0")
            world_x = int(input("世界宽度 (默认200): ") or "200")
            world_y = int(input("世界高度 (默认200): ") or "200")
            
            result = quick_experiment(
                num_robots=num_robots,
                communication_range=comm_range,
                world_size=(world_x, world_y),
                spawn_range=(world_x * 0.25, world_x * 0.75)
            )
            
            results = [result]
            
        elif choice == "2":
            # 参数扫描实验
            results = run_parameter_sweep()
            
        elif choice == "3":
            # 随机参数实验
            num_exp = int(input("实验次数 (默认10): ") or "10")
            results = run_random_experiments(num_exp)
            
        elif choice == "4":
            # 自定义实验
            print("自定义实验参数:")
            num_robots = int(input("机器人数量: "))
            comm_range = float(input("通信范围: "))
            world_x = int(input("世界宽度: "))
            world_y = int(input("世界高度: "))
            num_exp = int(input("实验次数: "))
            
            results = []
            for i in range(num_exp):
                print(f"\n--- 实验 {i+1}/{num_exp} ---")
                result = quick_experiment(
                    num_robots=num_robots,
                    communication_range=comm_range,
                    world_size=(world_x, world_y),
                    spawn_range=(world_x * 0.25, world_x * 0.75)
                )
                results.append(result)
        
        else:
            print("无效选择，使用单次实验")
            results = [quick_experiment()]
        
        # 保存结果
        if results:
            csv_file = save_results_to_csv(results)
            print_summary(results)
            print(f"\n结果文件: {csv_file}")
        
    except KeyboardInterrupt:
        print("\n实验被用户中断")
    except Exception as e:
        print(f"实验过程中出现错误: {e}")

if __name__ == "__main__":
    main()
