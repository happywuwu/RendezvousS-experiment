#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快速测试脚本
"""

from quick_experiment import quick_experiment, run_parameter_sweep, print_summary, save_results_to_csv

def test_single_experiment():
    """测试单次实验"""
    print("测试单次实验...")
    
    result = quick_experiment(
        num_robots=6,
        communication_range=15.0,
        world_size=(200, 200),
        spawn_range=(50, 150),
        max_time=300.0
    )
    
    print(f"实验结果: {result}")
    return [result]

def test_parameter_sweep():
    """测试参数扫描"""
    print("测试参数扫描实验...")
    
    results = []
    
    # 测试不同通信范围
    for comm_range in [10.0, 15.0, 20.0]:
        print(f"\n测试通信范围: {comm_range}")
        result = quick_experiment(
            num_robots=6,
            communication_range=comm_range,
            world_size=(150, 150),
            spawn_range=(50, 100),
            max_time=200.0
        )
        results.append(result)
    
    return results

def main():
    """主函数"""
    print("机器人交会算法快速测试")
    print("=" * 40)
    
    # 单次实验测试
    print("1. 单次实验测试")
    results = test_single_experiment()
    
    # 参数扫描测试
    print("\n2. 参数扫描测试")
    param_results = test_parameter_sweep()
    results.extend(param_results)
    
    # 保存结果
    if results:
        csv_file = save_results_to_csv(results)
        print_summary(results)
        print(f"\n结果文件: {csv_file}")
    
    print("\n测试完成！")

if __name__ == "__main__":
    main()
