#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
机器人交会算法测试脚本
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from main import RobotSimulation, Position, RobotRole

def test_basic_functionality():
    """测试基本功能"""
    print("测试基本功能...")
    
    try:
        # 创建模拟
        sim = RobotSimulation(num_robots=4, communication_range=10.0, world_size=(100, 100))
        
        # 检查机器人数量
        assert len(sim.robots) == 4, f"期望4个机器人，实际{len(sim.robots)}个"
        
        # 检查所有机器人初始状态
        for robot in sim.robots:
            assert robot.role == RobotRole.REGULAR_EXPLORER, f"机器人{robot.id}初始角色错误"
            assert robot.state.value == "exploring", f"机器人{robot.id}初始状态错误"
        
        print("OK 基本功能测试通过")
        return True
        
    except Exception as e:
        print(f"FAIL 基本功能测试失败: {e}")
        return False

def test_robot_movement():
    """测试机器人移动"""
    print("测试机器人移动...")
    
    try:
        sim = RobotSimulation(num_robots=2, communication_range=10.0, world_size=(50, 50))
        
        # 记录初始位置
        initial_positions = [robot.position for robot in sim.robots]
        
        # 运行几步模拟
        for _ in range(10):
            sim.update_simulation(dt=0.1)
        
        # 检查位置是否发生变化
        for i, robot in enumerate(sim.robots):
            if robot.role == RobotRole.REGULAR_EXPLORER:
                distance = robot.position.distance_to(initial_positions[i])
                assert distance > 0, f"机器人{robot.id}没有移动"
        
        print("OK 机器人移动测试通过")
        return True
        
    except Exception as e:
        print(f"FAIL 机器人移动测试失败: {e}")
        return False

def test_robot_encounter():
    """测试机器人相遇"""
    print("测试机器人相遇...")
    
    try:
        sim = RobotSimulation(num_robots=2, communication_range=50.0, world_size=(50, 50))
        
        # 将两个机器人放在很近的位置
        sim.robots[0].position = Position(25, 25)
        sim.robots[1].position = Position(26, 26)
        
        # 运行模拟
        for _ in range(5):
            sim.update_simulation(dt=0.1)
        
        # 检查是否有角色变化
        roles = [robot.role for robot in sim.robots]
        has_leader = any(role == RobotRole.LEADER for role in roles)
        has_sentry = any(role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY] for role in roles)
        
        if has_leader and has_sentry:
            print("OK 机器人相遇测试通过")
            return True
        else:
            print("WARN 机器人相遇测试部分通过（可能需要更多时间）")
            return True
        
    except Exception as e:
        print(f"FAIL 机器人相遇测试失败: {e}")
        return False

def run_all_tests():
    """运行所有测试"""
    print("开始机器人交会算法测试...")
    print("=" * 50)
    
    tests = [
        test_basic_functionality,
        test_robot_movement,
        test_robot_encounter
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
        print()
    
    print("=" * 50)
    print(f"测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("SUCCESS 所有测试通过！程序可以正常运行。")
    else:
        print("WARN 部分测试失败，但程序可能仍然可以运行。")
    
    return passed == total

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
