#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文实验结果分析工具
分析Figure 3的实验结果，生成统计图表
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from typing import List, Dict
import os

def load_experiment_data(csv_file: str) -> pd.DataFrame:
    """加载实验数据"""
    try:
        df = pd.read_csv(csv_file)
        print(f"成功加载数据: {len(df)} 条记录")
        return df
    except Exception as e:
        print(f"加载数据失败: {e}")
        return None

def analyze_figure_3a(df: pd.DataFrame):
    """分析Figure 3(A)结果"""
    print("\n" + "=" * 60)
    print("Figure 3(A) 分析: 环境大小和可视范围R对总移动距离的影响")
    print("=" * 60)
    
    # 筛选Figure 3(A)数据
    figure_3a_data = df[df['experiment_type'] == 'figure_3a'].copy()
    
    if figure_3a_data.empty:
        print("没有Figure 3(A)数据")
        return
    
    # 1. 环境大小对总移动距离的影响
    print("\n1. 环境大小对总移动距离的影响:")
    world_size_analysis = figure_3a_data.groupby(['world_size_x', 'world_size_y'])['total_travel_distance'].agg(['mean', 'std', 'count']).round(2)
    print(world_size_analysis)
    
    # 2. 可视范围R对总移动距离的影响
    print("\n2. 可视范围R对总移动距离的影响:")
    comm_range_analysis = figure_3a_data.groupby('communication_range')['total_travel_distance'].agg(['mean', 'std', 'count']).round(2)
    print(comm_range_analysis)
    
    # 3. 创建可视化图表
    create_figure_3a_plots(figure_3a_data)

def analyze_figure_3b(df: pd.DataFrame):
    """分析Figure 3(B)结果"""
    print("\n" + "=" * 60)
    print("Figure 3(B) 分析: 环境大小和机器人数量k对总移动距离的影响")
    print("=" * 60)
    
    # 筛选Figure 3(B)数据
    figure_3b_data = df[df['experiment_type'] == 'figure_3b'].copy()
    
    if figure_3b_data.empty:
        print("没有Figure 3(B)数据")
        return
    
    # 1. 环境大小对总移动距离的影响
    print("\n1. 环境大小对总移动距离的影响:")
    world_size_analysis = figure_3b_data.groupby(['world_size_x', 'world_size_y'])['total_travel_distance'].agg(['mean', 'std', 'count']).round(2)
    print(world_size_analysis)
    
    # 2. 机器人数量k对总移动距离的影响
    print("\n2. 机器人数量k对总移动距离的影响:")
    robot_count_analysis = figure_3b_data.groupby('num_robots')['total_travel_distance'].agg(['mean', 'std', 'count']).round(2)
    print(robot_count_analysis)
    
    # 3. 创建可视化图表
    create_figure_3b_plots(figure_3b_data)

def create_figure_3a_plots(df: pd.DataFrame):
    """创建Figure 3(A)的可视化图表"""
    print("\n创建Figure 3(A)可视化图表...")
    
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    # 创建子图
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Figure 3(A): 环境大小和可视范围R对总移动距离的影响', fontsize=16)
    
    # 1. 环境大小对总移动距离的影响
    ax1 = axes[0, 0]
    world_sizes = df.groupby(['world_size_x', 'world_size_y'])['total_travel_distance'].mean()
    world_size_labels = [f"{x}×{y}" for x, y in world_sizes.index]
    ax1.plot(range(len(world_size_labels)), world_sizes.values, 'bo-', linewidth=2, markersize=8)
    ax1.set_xlabel('环境大小')
    ax1.set_ylabel('总移动距离')
    ax1.set_title('环境大小对总移动距离的影响')
    ax1.set_xticks(range(len(world_size_labels)))
    ax1.set_xticklabels(world_size_labels)
    ax1.grid(True, alpha=0.3)
    
    # 2. 可视范围R对总移动距离的影响
    ax2 = axes[0, 1]
    comm_ranges = df.groupby('communication_range')['total_travel_distance'].mean()
    ax2.plot(comm_ranges.index, comm_ranges.values, 'ro-', linewidth=2, markersize=8)
    ax2.set_xlabel('可视范围 R')
    ax2.set_ylabel('总移动距离')
    ax2.set_title('可视范围R对总移动距离的影响')
    ax2.grid(True, alpha=0.3)
    
    # 3. 热力图：环境大小 vs 可视范围R
    ax3 = axes[1, 0]
    pivot_data = df.pivot_table(
        values='total_travel_distance', 
        index='world_size_x', 
        columns='communication_range', 
        aggfunc='mean'
    )
    im = ax3.imshow(pivot_data.values, cmap='YlOrRd', aspect='auto')
    ax3.set_xticks(range(len(pivot_data.columns)))
    ax3.set_xticklabels(pivot_data.columns)
    ax3.set_yticks(range(len(pivot_data.index)))
    ax3.set_yticklabels(pivot_data.index)
    ax3.set_title('环境大小 vs 可视范围R 热力图')
    ax3.set_xlabel('可视范围 R')
    ax3.set_ylabel('环境大小 (X)')
    plt.colorbar(im, ax=ax3)
    
    # 4. 散点图：环境面积 vs 总移动距离
    ax4 = axes[1, 1]
    scatter = ax4.scatter(df['world_area'], df['total_travel_distance'], 
                         c=df['communication_range'], cmap='viridis', alpha=0.7)
    ax4.set_xlabel('环境面积')
    ax4.set_ylabel('总移动距离')
    ax4.set_title('环境面积 vs 总移动距离')
    plt.colorbar(scatter, ax=ax4, label='可视范围 R')
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('figure_3a_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("Figure 3(A)图表已保存为: figure_3a_analysis.png")

def create_figure_3b_plots(df: pd.DataFrame):
    """创建Figure 3(B)的可视化图表"""
    print("\n创建Figure 3(B)可视化图表...")
    
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    # 创建子图
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Figure 3(B): 环境大小和机器人数量k对总移动距离的影响', fontsize=16)
    
    # 1. 环境大小对总移动距离的影响
    ax1 = axes[0, 0]
    world_sizes = df.groupby(['world_size_x', 'world_size_y'])['total_travel_distance'].mean()
    world_size_labels = [f"{x}×{y}" for x, y in world_sizes.index]
    ax1.plot(range(len(world_size_labels)), world_sizes.values, 'bo-', linewidth=2, markersize=8)
    ax1.set_xlabel('环境大小')
    ax1.set_ylabel('总移动距离')
    ax1.set_title('环境大小对总移动距离的影响')
    ax1.set_xticks(range(len(world_size_labels)))
    ax1.set_xticklabels(world_size_labels)
    ax1.grid(True, alpha=0.3)
    
    # 2. 机器人数量k对总移动距离的影响
    ax2 = axes[0, 1]
    robot_counts = df.groupby('num_robots')['total_travel_distance'].mean()
    ax2.plot(robot_counts.index, robot_counts.values, 'go-', linewidth=2, markersize=8)
    ax2.set_xlabel('机器人数量 k')
    ax2.set_ylabel('总移动距离')
    ax2.set_title('机器人数量k对总移动距离的影响')
    ax2.grid(True, alpha=0.3)
    
    # 3. 热力图：环境大小 vs 机器人数量k
    ax3 = axes[1, 0]
    pivot_data = df.pivot_table(
        values='total_travel_distance', 
        index='world_size_x', 
        columns='num_robots', 
        aggfunc='mean'
    )
    im = ax3.imshow(pivot_data.values, cmap='YlGnBu', aspect='auto')
    ax3.set_xticks(range(len(pivot_data.columns)))
    ax3.set_xticklabels(pivot_data.columns)
    ax3.set_yticks(range(len(pivot_data.index)))
    ax3.set_yticklabels(pivot_data.index)
    ax3.set_title('环境大小 vs 机器人数量k 热力图')
    ax3.set_xlabel('机器人数量 k')
    ax3.set_ylabel('环境大小 (X)')
    plt.colorbar(im, ax=ax3)
    
    # 4. 散点图：环境面积 vs 总移动距离
    ax4 = axes[1, 1]
    scatter = ax4.scatter(df['world_area'], df['total_travel_distance'], 
                         c=df['num_robots'], cmap='plasma', alpha=0.7)
    ax4.set_xlabel('环境面积')
    ax4.set_ylabel('总移动距离')
    ax4.set_title('环境面积 vs 总移动距离')
    plt.colorbar(scatter, ax=ax4, label='机器人数量 k')
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('figure_3b_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("Figure 3(B)图表已保存为: figure_3b_analysis.png")

def generate_summary_report(df: pd.DataFrame):
    """生成总结报告"""
    print("\n" + "=" * 60)
    print("实验总结报告")
    print("=" * 60)
    
    # 基本统计
    total_experiments = len(df)
    successful_experiments = len(df[df['success'] == True])
    success_rate = successful_experiments / total_experiments * 100
    
    print(f"总实验数: {total_experiments}")
    print(f"成功实验数: {successful_experiments}")
    print(f"成功率: {success_rate:.1f}%")
    
    # 总移动距离统计
    print(f"\n总移动距离统计:")
    print(f"  平均值: {df['total_travel_distance'].mean():.1f}")
    print(f"  中位数: {df['total_travel_distance'].median():.1f}")
    print(f"  标准差: {df['total_travel_distance'].std():.1f}")
    print(f"  最小值: {df['total_travel_distance'].min():.1f}")
    print(f"  最大值: {df['total_travel_distance'].max():.1f}")
    
    # 参数范围
    print(f"\n实验参数范围:")
    print(f"  机器人数量: {df['num_robots'].min()} - {df['num_robots'].max()}")
    print(f"  可视范围R: {df['communication_range'].min()} - {df['communication_range'].max()}")
    print(f"  环境大小: {df['world_size_x'].min()}×{df['world_size_y'].min()} - {df['world_size_x'].max()}×{df['world_size_y'].max()}")
    
    # 相关性分析
    print(f"\n相关性分析:")
    correlations = df[['num_robots', 'communication_range', 'world_area', 'total_travel_distance']].corr()
    print(f"  机器人数量与总移动距离的相关性: {correlations.loc['num_robots', 'total_travel_distance']:.3f}")
    print(f"  可视范围R与总移动距离的相关性: {correlations.loc['communication_range', 'total_travel_distance']:.3f}")
    print(f"  环境面积与总移动距离的相关性: {correlations.loc['world_area', 'total_travel_distance']:.3f}")

def main():
    """主函数"""
    print("论文实验结果分析工具")
    print("=" * 60)
    
    # 查找最新的结果文件
    result_files = []
    
    # 首先在当前目录查找
    for file in os.listdir('.'):
        if file.startswith('paper_experiment_results_') and file.endswith('.csv'):
            result_files.append(file)
    
    # 然后在paper_experiment_results目录查找
    if os.path.exists('paper_experiment_results'):
        for file in os.listdir('paper_experiment_results'):
            if file.startswith('paper_experiment_results_') and file.endswith('.csv'):
                result_files.append(os.path.join('paper_experiment_results', file))
    
    if not result_files:
        print("没有找到实验结果文件")
        print("请先运行: python paper_experiment.py")
        return
    
    # 选择最新的文件
    latest_file = max(result_files)
    print(f"使用结果文件: {latest_file}")
    
    # 加载数据
    df = load_experiment_data(latest_file)
    if df is None:
        return
    
    # 分析结果
    analyze_figure_3a(df)
    analyze_figure_3b(df)
    generate_summary_report(df)
    
    print("\n分析完成！")
    print("生成的图表文件:")
    print("  - figure_3a_analysis.png")
    print("  - figure_3b_analysis.png")

if __name__ == "__main__":
    main()
