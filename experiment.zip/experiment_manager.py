#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
机器人交会算法实验管理系统
支持多次实验、参数调整、数据记录
"""

import csv
import json
import time
import random
from datetime import datetime
from typing import List, Dict, Tuple, Optional
import os

from main import RobotSimulation, RobotRole

class ExperimentConfig:
    """实验配置类"""
    
    def __init__(self):
        # 基本参数
        self.num_robots_range = (4, 12)  # 机器人数量范围
        self.communication_range_range = (5.0, 30.0)  # 通信范围范围
        self.world_size_range = ((100, 100), (300, 300))  # 世界大小范围
        self.spawn_range_ratio = (0.1, 0.9)  # 生成范围比例
        
        # 实验参数
        self.num_experiments = 10  # 实验次数
        self.max_simulation_time = 1000.0  # 最大模拟时间
        self.time_step = 0.5  # 时间步长
        
        # 输出设置
        self.output_dir = "experiment_results"
        self.save_visualization = False
        self.save_detailed_log = True

class ExperimentResult:
    """实验结果类"""
    
    def __init__(self, experiment_id: str):
        self.experiment_id = experiment_id
        self.config = {}
        self.rendezvous_time = None
        self.success = False
        self.final_roles = {}
        self.leader_count = 0
        self.sentry_count = 0
        self.member_count = 0
        self.explorer_count = 0
        self.simulation_time = 0.0
        self.rendezvous_location = None
        self.initial_positions = []
        self.final_positions = []

class ExperimentManager:
    """实验管理器"""
    
    def __init__(self, config: ExperimentConfig = None):
        self.config = config or ExperimentConfig()
        self.results: List[ExperimentResult] = []
        self.current_experiment = None
        
        # 创建输出目录
        os.makedirs(self.config.output_dir, exist_ok=True)
    
    def generate_random_config(self) -> Dict:
        """生成随机实验配置"""
        # 随机选择参数
        num_robots = random.randint(*self.config.num_robots_range)
        communication_range = random.uniform(*self.config.communication_range_range)
        
        # 世界大小
        world_size_min, world_size_max = self.config.world_size_range
        world_size = (
            random.randint(world_size_min[0], world_size_max[0]),
            random.randint(world_size_min[1], world_size_max[1])
        )
        
        # 生成范围
        spawn_range = (
            world_size[0] * self.config.spawn_range_ratio[0],
            world_size[0] * self.config.spawn_range_ratio[1]
        )
        
        return {
            'num_robots': num_robots,
            'communication_range': communication_range,
            'world_size': world_size,
            'spawn_range': spawn_range,
            'max_time': self.config.max_simulation_time,
            'time_step': self.config.time_step
        }
    
    def run_single_experiment(self, config: Dict, experiment_id: str) -> ExperimentResult:
        """运行单次实验"""
        print(f"开始实验 {experiment_id}...")
        print(f"  机器人数量: {config['num_robots']}")
        print(f"  通信范围: {config['communication_range']:.1f}")
        print(f"  世界大小: {config['world_size']}")
        print(f"  生成范围: {config['spawn_range']}")
        
        # 创建模拟
        sim = RobotSimulation(
            num_robots=config['num_robots'],
            communication_range=config['communication_range'],
            world_size=config['world_size'],
            robot_spawn_range=config['spawn_range']
        )
        sim.experiment_id = experiment_id
        
        # 记录初始位置
        initial_positions = [(r.position.x, r.position.y) for r in sim.robots]
        
        # 运行模拟
        start_time = time.time()
        step_count = 0
        
        while sim.simulation_time < config['max_time']:
            sim.update_simulation(dt=config['time_step'])
            step_count += 1
            
            # 检查是否完成交会
            if sim.rendezvous_phase and self.check_rendezvous_completion(sim):
                break
            
            # 每100步显示进度
            if step_count % 100 == 0:
                print(f"    步骤 {step_count}, 时间 {sim.simulation_time:.1f}")
        
        # 记录结果
        result = ExperimentResult(experiment_id)
        result.config = config.copy()
        result.rendezvous_time = sim.rendezvous_time
        result.success = sim.rendezvous_phase
        result.simulation_time = sim.simulation_time
        result.rendezvous_location = sim.rendezvous_location
        result.initial_positions = initial_positions
        result.final_positions = [(r.position.x, r.position.y) for r in sim.robots]
        
        # 统计最终角色分布
        for robot in sim.robots:
            role = robot.role.value
            if role not in result.final_roles:
                result.final_roles[role] = 0
            result.final_roles[role] += 1
        
        result.leader_count = result.final_roles.get('leader', 0)
        result.sentry_count = result.final_roles.get('primary_sentry', 0) + result.final_roles.get('secondary_sentry', 0)
        result.member_count = result.final_roles.get('member', 0)
        result.explorer_count = result.final_roles.get('regular_explorer', 0)
        
        # 计算实际运行时间
        actual_time = time.time() - start_time
        
        print(f"  实验完成: {'成功' if result.success else '失败'}")
        print(f"  交会时间: {result.rendezvous_time:.1f if result.rendezvous_time else 'N/A'}")
        print(f"  模拟时间: {result.simulation_time:.1f}")
        print(f"  实际运行时间: {actual_time:.2f}秒")
        print(f"  最终角色分布: 领导者={result.leader_count}, 哨兵={result.sentry_count}, 成员={result.member_count}, 探索者={result.explorer_count}")
        
        return result
    
    def check_rendezvous_completion(self, sim) -> bool:
        """检查交会是否完成"""
        if not sim.rendezvous_location:
            return False
        
        # 检查所有机器人是否都接近交会位置
        threshold = sim.communication_range * 2  # 交会完成阈值
        
        for robot in sim.robots:
            distance = robot.position.distance_to(sim.rendezvous_location)
            if distance > threshold:
                return False
        
        return True
    
    def run_batch_experiments(self, custom_configs: List[Dict] = None) -> List[ExperimentResult]:
        """运行批量实验"""
        print("=" * 60)
        print("开始批量实验")
        print("=" * 60)
        
        self.results = []
        
        if custom_configs:
            configs = custom_configs
        else:
            # 生成随机配置
            configs = []
            for i in range(self.config.num_experiments):
                configs.append(self.generate_random_config())
        
        for i, config in enumerate(configs):
            experiment_id = f"exp_{i+1:03d}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            try:
                result = self.run_single_experiment(config, experiment_id)
                self.results.append(result)
                print(f"实验 {i+1}/{len(configs)} 完成\n")
                
            except Exception as e:
                print(f"实验 {i+1} 失败: {e}")
                # 创建失败结果
                result = ExperimentResult(experiment_id)
                result.config = config
                result.success = False
                self.results.append(result)
        
        return self.results
    
    def save_results_to_csv(self, filename: str = None):
        """保存结果到CSV文件"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"experiment_results_{timestamp}.csv"
        
        filepath = os.path.join(self.config.output_dir, filename)
        
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'experiment_id', 'success', 'rendezvous_time', 'simulation_time',
                'num_robots', 'communication_range', 'world_size_x', 'world_size_y',
                'spawn_range_min', 'spawn_range_max',
                'leader_count', 'sentry_count', 'member_count', 'explorer_count',
                'rendezvous_location_x', 'rendezvous_location_y'
            ]
            
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for result in self.results:
                row = {
                    'experiment_id': result.experiment_id,
                    'success': result.success,
                    'rendezvous_time': result.rendezvous_time,
                    'simulation_time': result.simulation_time,
                    'num_robots': result.config['num_robots'],
                    'communication_range': result.config['communication_range'],
                    'world_size_x': result.config['world_size'][0],
                    'world_size_y': result.config['world_size'][1],
                    'spawn_range_min': result.config['spawn_range'][0],
                    'spawn_range_max': result.config['spawn_range'][1],
                    'leader_count': result.leader_count,
                    'sentry_count': result.sentry_count,
                    'member_count': result.member_count,
                    'explorer_count': result.explorer_count,
                    'rendezvous_location_x': result.rendezvous_location.x if result.rendezvous_location else None,
                    'rendezvous_location_y': result.rendezvous_location.y if result.rendezvous_location else None
                }
                writer.writerow(row)
        
        print(f"结果已保存到: {filepath}")
        return filepath
    
    def save_results_to_json(self, filename: str = None):
        """保存详细结果到JSON文件"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"experiment_details_{timestamp}.json"
        
        filepath = os.path.join(self.config.output_dir, filename)
        
        # 转换结果为可序列化的格式
        serializable_results = []
        for result in self.results:
            serializable_result = {
                'experiment_id': result.experiment_id,
                'success': result.success,
                'rendezvous_time': result.rendezvous_time,
                'simulation_time': result.simulation_time,
                'config': result.config,
                'final_roles': result.final_roles,
                'leader_count': result.leader_count,
                'sentry_count': result.sentry_count,
                'member_count': result.member_count,
                'explorer_count': result.explorer_count,
                'rendezvous_location': {
                    'x': result.rendezvous_location.x,
                    'y': result.rendezvous_location.y
                } if result.rendezvous_location else None,
                'initial_positions': result.initial_positions,
                'final_positions': result.final_positions
            }
            serializable_results.append(serializable_result)
        
        with open(filepath, 'w', encoding='utf-8') as jsonfile:
            json.dump(serializable_results, jsonfile, indent=2, ensure_ascii=False)
        
        print(f"详细结果已保存到: {filepath}")
        return filepath
    
    def print_summary(self):
        """打印实验总结"""
        if not self.results:
            print("没有实验结果")
            return
        
        print("\n" + "=" * 60)
        print("实验总结")
        print("=" * 60)
        
        total_experiments = len(self.results)
        successful_experiments = sum(1 for r in self.results if r.success)
        success_rate = successful_experiments / total_experiments * 100
        
        print(f"总实验数: {total_experiments}")
        print(f"成功实验数: {successful_experiments}")
        print(f"成功率: {success_rate:.1f}%")
        
        if successful_experiments > 0:
            rendezvous_times = [r.rendezvous_time for r in self.results if r.success and r.rendezvous_time]
            if rendezvous_times:
                avg_rendezvous_time = sum(rendezvous_times) / len(rendezvous_times)
                min_rendezvous_time = min(rendezvous_times)
                max_rendezvous_time = max(rendezvous_times)
                
                print(f"\n交会时间统计:")
                print(f"  平均交会时间: {avg_rendezvous_time:.1f}")
                print(f"  最短交会时间: {min_rendezvous_time:.1f}")
                print(f"  最长交会时间: {max_rendezvous_time:.1f}")
        
        # 参数影响分析
        print(f"\n参数影响分析:")
        comm_ranges = [r.config['communication_range'] for r in self.results]
        robot_counts = [r.config['num_robots'] for r in self.results]
        
        print(f"  通信范围范围: {min(comm_ranges):.1f} - {max(comm_ranges):.1f}")
        print(f"  机器人数量范围: {min(robot_counts)} - {max(robot_counts)}")

def create_custom_experiments():
    """创建自定义实验配置"""
    experiments = []
    
    # 实验1: 固定参数测试
    experiments.append({
        'num_robots': 6,
        'communication_range': 15.0,
        'world_size': (200, 200),
        'spawn_range': (50, 150),
        'max_time': 500.0,
        'time_step': 0.5
    })
    
    # 实验2: 不同通信范围
    for comm_range in [10.0, 20.0, 30.0]:
        experiments.append({
            'num_robots': 8,
            'communication_range': comm_range,
            'world_size': (200, 200),
            'spawn_range': (50, 150),
            'max_time': 500.0,
            'time_step': 0.5
        })
    
    # 实验3: 不同机器人数量
    for num_robots in [4, 6, 8, 10]:
        experiments.append({
            'num_robots': num_robots,
            'communication_range': 15.0,
            'world_size': (200, 200),
            'spawn_range': (50, 150),
            'max_time': 500.0,
            'time_step': 0.5
        })
    
    return experiments

def main():
    """主函数"""
    print("机器人交会算法实验管理系统")
    print("=" * 60)
    
    # 创建实验配置
    config = ExperimentConfig()
    config.num_experiments = 20  # 实验次数
    config.max_simulation_time = 800.0  # 最大模拟时间
    
    # 创建实验管理器
    manager = ExperimentManager(config)
    
    print("选择实验模式:")
    print("1. 随机参数实验")
    print("2. 自定义参数实验")
    print("3. 快速测试（5次实验）")
    
    try:
        choice = input("请输入选择 (1-3): ").strip()
        
        if choice == "1":
            print("开始随机参数实验...")
            results = manager.run_batch_experiments()
            
        elif choice == "2":
            print("开始自定义参数实验...")
            custom_configs = create_custom_experiments()
            results = manager.run_batch_experiments(custom_configs)
            
        elif choice == "3":
            print("开始快速测试...")
            config.num_experiments = 5
            manager.config = config
            results = manager.run_batch_experiments()
            
        else:
            print("无效选择，使用随机参数实验...")
            results = manager.run_batch_experiments()
        
        # 保存结果
        csv_file = manager.save_results_to_csv()
        json_file = manager.save_results_to_json()
        
        # 打印总结
        manager.print_summary()
        
        print(f"\n结果文件:")
        print(f"  CSV: {csv_file}")
        print(f"  JSON: {json_file}")
        
    except KeyboardInterrupt:
        print("\n实验被用户中断")
    except Exception as e:
        print(f"实验过程中出现错误: {e}")

if __name__ == "__main__":
    main()
