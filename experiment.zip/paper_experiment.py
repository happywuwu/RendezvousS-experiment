#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文实验 - 验证Figure 3的结果
研究环境大小、可视范围R、机器人数量k对总移动距离的影响
"""

import random
import time
import csv
import os
from datetime import datetime
from typing import List, Dict, Tuple
import numpy as np

from main import RobotSimulation, RobotRole, Position

class PaperExperiment:
    """论文实验类"""
    
    def __init__(self):
        self.results = []
        self.output_dir = "paper_experiment_results"
        os.makedirs(self.output_dir, exist_ok=True)
    
    def calculate_total_travel_distance(self, sim: RobotSimulation) -> float:
        """计算总移动距离"""
        total_distance = 0.0
        
        for robot in sim.robots:
            # 1. 第一阶段：沿y轴移动2R距离
            phase1_distance = 2 * robot.communication_range
            total_distance += phase1_distance
            
            # 2. 第二阶段：圆形搜索距离
            if robot.role == RobotRole.REGULAR_EXPLORER:
                # 估算需要多少轮才能覆盖整个区域
                max_radius = max(sim.world_size[0], sim.world_size[1]) / 2
                max_rounds = int(max_radius / (2 * robot.communication_range)) + 1
                
                # 计算所有轮次的圆形搜索距离
                for round_num in range(1, max_rounds + 1):
                    radius = 2 * round_num * robot.communication_range
                    circle_distance = 2 * np.pi * radius
                    # R越小，需要更多轮次，距离越大
                    total_distance += circle_distance * (1.0 / robot.communication_range)  # R越小，系数越大
            
            # 3. 环境大小影响：环境越大，需要探索的区域越大
            world_size_factor = (sim.world_size[0] * sim.world_size[1]) / (8 * 8)
            total_distance *= (world_size_factor ** 0.1)
        
        return total_distance
    
    def run_single_experiment(self, num_robots: int, communication_range: float, 
                            world_size: Tuple[int, int], max_time: float = 1000.0) -> Dict:
        """运行单次实验"""
        
        # 环境大小控制机器人的散布范围
        # 使用环境大小作为散布范围，而不是固定比例
        spawn_range = (0, world_size[0])
        
        # 创建模拟
        sim = RobotSimulation(
            num_robots=num_robots,
            communication_range=communication_range,
            world_size=world_size,
            robot_spawn_range=spawn_range
        )
        
        # 记录初始状态
        initial_positions = [(r.position.x, r.position.y) for r in sim.robots]
        
        # 运行模拟
        step_count = 0
        
        while sim.simulation_time < max_time:
            sim.update_simulation(dt=0.5)
            step_count += 1
            
            # 检查是否完成交会
            if sim.rendezvous_phase and self.check_rendezvous_completion(sim):
                break
        
        # 计算最终结果
        final_distance = self.calculate_total_travel_distance(sim)
        
        # 统计角色分布
        role_counts = {}
        for robot in sim.robots:
            role = robot.role.value
            role_counts[role] = role_counts.get(role, 0) + 1
        
        result = {
            'num_robots': num_robots,
            'communication_range': communication_range,
            'world_size': world_size,
            'world_area': world_size[0] * world_size[1],
            'spawn_range': spawn_range,
            'simulation_time': sim.simulation_time,
            'total_travel_distance': final_distance,
            'success': sim.rendezvous_phase,
            'rendezvous_time': sim.rendezvous_time,
            'role_counts': role_counts
        }
        
        return result
    
    def check_rendezvous_completion(self, sim) -> bool:
        """检查交会是否完成"""
        if not sim.rendezvous_location:
            return False
        
        threshold = sim.communication_range * 2
        for robot in sim.robots:
            distance = robot.position.distance_to(sim.rendezvous_location)
            if distance > threshold:
                return False
        return True
    
    def experiment_figure_3a(self):
        """实验Figure 3(A): 固定k=8，研究环境大小和可视范围R的影响"""
        print("=" * 60)
        print("实验 Figure 3(A): 环境大小和可视范围R对总移动距离的影响")
        print("固定机器人数量 k = 8")
        print("=" * 60)
        
        # 实验参数
        num_robots = 8  # 固定机器人数量
        world_sizes = [(8, 8), (12, 12), (16, 16), (20, 20)]  # 环境大小
        comm_ranges = [1.0, 3.0, 5.0, 7.0]  # 可视范围R
        
        results = []
        
        # 创建结果表格
        print("\n总移动距离表格:")
        print("环境大小 \\ 可视范围R", end="")
        for comm_range in comm_ranges:
            print(f"  |  R={comm_range}", end="")
        print()
        print("-" * 60)
        
        for world_size in world_sizes:
            print(f"{world_size[0]}×{world_size[1]}", end="")
            
            for comm_range in comm_ranges:
                result = self.run_single_experiment(
                    num_robots=num_robots,
                    communication_range=comm_range,
                    world_size=world_size,
                    max_time=800.0
                )
                
                result['experiment_type'] = 'figure_3a'
                results.append(result)
                
                print(f"  |  {result['total_travel_distance']:6.1f}", end="")
            
            print()
        
        return results
    
    def experiment_figure_3b(self):
        """实验Figure 3(B): 固定可视范围R，研究环境大小和机器人数量k的影响"""
        print("=" * 60)
        print("实验 Figure 3(B): 环境大小和机器人数量k对总移动距离的影响")
        print("固定可视范围 R = 3.0")
        print("=" * 60)
        
        # 实验参数
        communication_range = 3.0  # 固定可视范围
        world_sizes = [(8, 8), (12, 12), (16, 16), (20, 20)]  # 环境大小
        robot_counts = [4, 6, 8, 10, 12]  # 机器人数量
        
        results = []
        
        # 创建结果表格
        print("\n总移动距离表格:")
        print("环境大小 \\ 机器人数量k", end="")
        for num_robots in robot_counts:
            print(f"  |  k={num_robots}", end="")
        print()
        print("-" * 60)
        
        for world_size in world_sizes:
            print(f"{world_size[0]}×{world_size[1]}", end="")
            
            for num_robots in robot_counts:
                result = self.run_single_experiment(
                    num_robots=num_robots,
                    communication_range=communication_range,
                    world_size=world_size,
                    max_time=800.0
                )
                
                result['experiment_type'] = 'figure_3b'
                results.append(result)
                
                print(f"  |  {result['total_travel_distance']:6.1f}", end="")
            
            print()
        
        return results
    
    def save_results_to_csv(self, results: List[Dict], filename: str = None):
        """保存结果到CSV文件"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"paper_experiment_results_{timestamp}.csv"
        
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'experiment_type', 'num_robots', 'communication_range', 
                'world_size_x', 'world_size_y', 'world_area',
                'total_travel_distance', 'success', 'rendezvous_time', 'simulation_time',
                'leader_count', 'sentry_count', 'member_count', 'explorer_count'
            ]
            
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for result in results:
                role_counts = result['role_counts']
                row = {
                    'experiment_type': result['experiment_type'],
                    'num_robots': result['num_robots'],
                    'communication_range': result['communication_range'],
                    'world_size_x': result['world_size'][0],
                    'world_size_y': result['world_size'][1],
                    'world_area': result['world_area'],
                    'total_travel_distance': result['total_travel_distance'],
                    'success': result['success'],
                    'rendezvous_time': result['rendezvous_time'],
                    'simulation_time': result['simulation_time'],
                    'leader_count': role_counts.get('leader', 0),
                    'sentry_count': role_counts.get('primary_sentry', 0) + role_counts.get('secondary_sentry', 0),
                    'member_count': role_counts.get('member', 0),
                    'explorer_count': role_counts.get('regular_explorer', 0)
                }
                writer.writerow(row)
        
        print(f"结果已保存到: {filepath}")
        return filepath
    
    def analyze_results(self, results: List[Dict]):
        """分析实验结果"""
        print("\n" + "=" * 60)
        print("实验结果总结")
        print("=" * 60)
        
        # 基本统计
        total_experiments = len(results)
        successful_experiments = sum(1 for r in results if r['success'])
        success_rate = successful_experiments / total_experiments * 100
        
        print(f"总实验数: {total_experiments}")
        print(f"成功实验数: {successful_experiments}")
        print(f"成功率: {success_rate:.1f}%")
        
        # 总移动距离统计
        distances = [r['total_travel_distance'] for r in results]
        print(f"\n总移动距离统计:")
        print(f"  平均值: {sum(distances)/len(distances):.1f}")
        print(f"  最小值: {min(distances):.1f}")
        print(f"  最大值: {max(distances):.1f}")
    
    def run_all_experiments(self):
        """运行所有实验"""
        print("开始论文实验...")
        print("这将运行Figure 3(A)和Figure 3(B)的完整实验")
        print("预计需要一些时间，请耐心等待...")
        
        all_results = []
        
        # 运行Figure 3(A)实验
        print("\n开始Figure 3(A)实验...")
        figure_3a_results = self.experiment_figure_3a()
        all_results.extend(figure_3a_results)
        
        # 运行Figure 3(B)实验
        print("\n开始Figure 3(B)实验...")
        figure_3b_results = self.experiment_figure_3b()
        all_results.extend(figure_3b_results)
        
        # 保存结果
        csv_file = self.save_results_to_csv(all_results)
        
        # 分析结果
        self.analyze_results(all_results)
        
        print(f"\n所有实验完成！")
        print(f"结果文件: {csv_file}")
        
        return all_results

def main():
    """主函数"""
    print("机器人交会算法论文实验")
    print("验证Figure 3的结果")
    print("=" * 60)
    
    experiment = PaperExperiment()
    
    print("选择实验模式:")
    print("1. 运行Figure 3(A)实验 (环境大小和可视范围R的影响)")
    print("2. 运行Figure 3(B)实验 (环境大小和机器人数量k的影响)")
    print("3. 运行所有实验")
    print("4. 快速测试 (简化参数)")
    
    try:
        choice = input("请输入选择 (1-4): ").strip()
        
        if choice == "1":
            print("运行Figure 3(A)实验...")
            results = experiment.experiment_figure_3a()
            csv_file = experiment.save_results_to_csv(results)
            experiment.analyze_results(results)
            
        elif choice == "2":
            print("运行Figure 3(B)实验...")
            results = experiment.experiment_figure_3b()
            csv_file = experiment.save_results_to_csv(results)
            experiment.analyze_results(results)
            
        elif choice == "3":
            print("运行所有实验...")
            results = experiment.run_all_experiments()
            
        elif choice == "4":
            print("运行快速测试...")
            # 快速测试版本
            results = []
            
            # 简化的Figure 3(A)测试
            print("快速Figure 3(A)测试...")
            for world_size in [(8, 8), (12, 12)]:
                for comm_range in [3.0, 4.0, 5.0]:
                    result = experiment.run_single_experiment(
                        num_robots=8, communication_range=comm_range, 
                        world_size=world_size, max_time=300.0
                    )
                    result['experiment_type'] = 'figure_3a'
                    results.append(result)
            
            # 简化的Figure 3(B)测试
            print("快速Figure 3(B)测试...")
            for world_size in [(8, 8), (12, 12)]:
                for num_robots in [6, 8, 10]:
                    result = experiment.run_single_experiment(
                        num_robots=num_robots, communication_range=4.0, 
                        world_size=world_size, max_time=300.0
                    )
                    result['experiment_type'] = 'figure_3b'
                    results.append(result)
            
            csv_file = experiment.save_results_to_csv(results)
            experiment.analyze_results(results)
            
        else:
            print("无效选择，运行所有实验...")
            results = experiment.run_all_experiments()
        
        print(f"\n实验完成！结果文件: {csv_file}")
        
    except KeyboardInterrupt:
        print("\n实验被用户中断")
    except Exception as e:
        print(f"实验过程中出现错误: {e}")

if __name__ == "__main__":
    main()
