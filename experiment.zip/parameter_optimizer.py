#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
参数优化工具 - 帮助找到最佳参数组合
"""

import random
import time
from typing import List, Dict, Tuple
import csv
from datetime import datetime

from quick_experiment import quick_experiment, print_summary, save_results_to_csv

class ParameterOptimizer:
    """参数优化器"""
    
    def __init__(self):
        self.results = []
        self.best_config = None
        self.best_score = float('inf')
    
    def evaluate_config(self, config: Dict) -> float:
        """评估配置的性能"""
        try:
            result = quick_experiment(
                num_robots=config['num_robots'],
                communication_range=config['communication_range'],
                world_size=config['world_size'],
                spawn_range=config['spawn_range'],
                max_time=config['max_time']
            )
            
            # 计算评分（越小越好）
            if result['success'] and result['rendezvous_time']:
                # 成功：交会时间越短越好
                score = result['rendezvous_time']
            else:
                # 失败：给予惩罚分数
                score = result['simulation_time'] * 2
            
            # 记录结果
            result['config'] = config
            result['score'] = score
            self.results.append(result)
            
            return score
            
        except Exception as e:
            print(f"评估配置失败: {e}")
            return float('inf')
    
    def random_search(self, num_trials: int = 20) -> Dict:
        """随机搜索最佳参数"""
        print(f"开始随机搜索 ({num_trials}次试验)...")
        
        # 参数范围
        robot_counts = [4, 6, 8, 10, 12]
        comm_ranges = [8.0, 12.0, 16.0, 20.0, 24.0, 28.0]
        world_sizes = [(100, 100), (150, 150), (200, 200), (250, 250)]
        
        for i in range(num_trials):
            print(f"\n试验 {i+1}/{num_trials}")
            
            # 随机选择参数
            num_robots = random.choice(robot_counts)
            comm_range = random.choice(comm_ranges)
            world_size = random.choice(world_sizes)
            
            # 计算生成范围
            spawn_range = (world_size[0] * 0.2, world_size[0] * 0.8)
            
            config = {
                'num_robots': num_robots,
                'communication_range': comm_range,
                'world_size': world_size,
                'spawn_range': spawn_range,
                'max_time': 400.0
            }
            
            print(f"参数: 机器人={num_robots}, 通信范围={comm_range}, 世界大小={world_size}")
            
            score = self.evaluate_config(config)
            
            if score < self.best_score:
                self.best_score = score
                self.best_config = config.copy()
                print(f"*** 新的最佳配置! 评分: {score:.1f} ***")
            else:
                print(f"评分: {score:.1f}")
        
        return self.best_config
    
    def grid_search(self) -> Dict:
        """网格搜索最佳参数"""
        print("开始网格搜索...")
        
        # 定义搜索网格
        robot_counts = [6, 8, 10]
        comm_ranges = [12.0, 16.0, 20.0]
        world_sizes = [(150, 150), (200, 200)]
        
        total_combinations = len(robot_counts) * len(comm_ranges) * len(world_sizes)
        current = 0
        
        for num_robots in robot_counts:
            for comm_range in comm_ranges:
                for world_size in world_sizes:
                    current += 1
                    print(f"\n网格搜索 {current}/{total_combinations}")
                    
                    spawn_range = (world_size[0] * 0.2, world_size[0] * 0.8)
                    
                    config = {
                        'num_robots': num_robots,
                        'communication_range': comm_range,
                        'world_size': world_size,
                        'spawn_range': spawn_range,
                        'max_time': 400.0
                    }
                    
                    print(f"参数: 机器人={num_robots}, 通信范围={comm_range}, 世界大小={world_size}")
                    
                    score = self.evaluate_config(config)
                    
                    if score < self.best_score:
                        self.best_score = score
                        self.best_config = config.copy()
                        print(f"*** 新的最佳配置! 评分: {score:.1f} ***")
                    else:
                        print(f"评分: {score:.1f}")
        
        return self.best_config
    
    def find_high_success_configs(self) -> List[Dict]:
        """找到高成功率的配置"""
        successful_configs = []
        
        for result in self.results:
            if result['success'] and result['rendezvous_time']:
                successful_configs.append({
                    'config': result['config'],
                    'rendezvous_time': result['rendezvous_time'],
                    'score': result['score']
                })
        
        # 按交会时间排序
        successful_configs.sort(key=lambda x: x['rendezvous_time'])
        
        return successful_configs
    
    def analyze_parameter_impact(self):
        """分析参数影响"""
        if not self.results:
            print("没有实验结果")
            return
        
        print("\n" + "=" * 60)
        print("参数影响分析")
        print("=" * 60)
        
        # 按通信范围分组
        comm_range_groups = {}
        for result in self.results:
            comm_range = result['config']['communication_range']
            if comm_range not in comm_range_groups:
                comm_range_groups[comm_range] = []
            comm_range_groups[comm_range].append(result)
        
        print("\n通信范围影响:")
        for comm_range in sorted(comm_range_groups.keys()):
            group = comm_range_groups[comm_range]
            success_count = sum(1 for r in group if r['success'])
            success_rate = success_count / len(group) * 100
            avg_time = sum(r['rendezvous_time'] for r in group if r['success'] and r['rendezvous_time']) / max(1, success_count)
            print(f"  通信范围 {comm_range}: 成功率 {success_rate:.1f}%, 平均交会时间 {avg_time:.1f}")
        
        # 按机器人数量分组
        robot_count_groups = {}
        for result in self.results:
            num_robots = result['config']['num_robots']
            if num_robots not in robot_count_groups:
                robot_count_groups[num_robots] = []
            robot_count_groups[num_robots].append(result)
        
        print("\n机器人数量影响:")
        for num_robots in sorted(robot_count_groups.keys()):
            group = robot_count_groups[num_robots]
            success_count = sum(1 for r in group if r['success'])
            success_rate = success_count / len(group) * 100
            avg_time = sum(r['rendezvous_time'] for r in group if r['success'] and r['rendezvous_time']) / max(1, success_count)
            print(f"  机器人数量 {num_robots}: 成功率 {success_rate:.1f}%, 平均交会时间 {avg_time:.1f}")
    
    def save_optimization_results(self, filename: str = None):
        """保存优化结果"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"optimization_results_{timestamp}.csv"
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'experiment_id', 'success', 'rendezvous_time', 'score',
                'num_robots', 'communication_range', 'world_size_x', 'world_size_y',
                'spawn_range_min', 'spawn_range_max'
            ]
            
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for i, result in enumerate(self.results):
                row = {
                    'experiment_id': f'opt_{i+1:03d}',
                    'success': result['success'],
                    'rendezvous_time': result['rendezvous_time'],
                    'score': result['score'],
                    'num_robots': result['config']['num_robots'],
                    'communication_range': result['config']['communication_range'],
                    'world_size_x': result['config']['world_size'][0],
                    'world_size_y': result['config']['world_size'][1],
                    'spawn_range_min': result['config']['spawn_range'][0],
                    'spawn_range_max': result['config']['spawn_range'][1]
                }
                writer.writerow(row)
        
        print(f"优化结果已保存到: {filename}")
        return filename

def main():
    """主函数"""
    print("机器人交会算法参数优化工具")
    print("=" * 60)
    
    optimizer = ParameterOptimizer()
    
    print("选择优化方法:")
    print("1. 随机搜索 (推荐)")
    print("2. 网格搜索")
    print("3. 快速测试")
    
    try:
        choice = input("请输入选择 (1-3): ").strip()
        
        if choice == "1":
            num_trials = int(input("试验次数 (默认20): ") or "20")
            best_config = optimizer.random_search(num_trials)
            
        elif choice == "2":
            best_config = optimizer.grid_search()
            
        elif choice == "3":
            # 快速测试几个配置
            test_configs = [
                {'num_robots': 6, 'communication_range': 15.0, 'world_size': (150, 150), 'spawn_range': (30, 120), 'max_time': 300.0},
                {'num_robots': 8, 'communication_range': 20.0, 'world_size': (200, 200), 'spawn_range': (50, 150), 'max_time': 300.0},
                {'num_robots': 10, 'communication_range': 25.0, 'world_size': (200, 200), 'spawn_range': (50, 150), 'max_time': 300.0}
            ]
            
            for i, config in enumerate(test_configs):
                print(f"\n测试配置 {i+1}:")
                score = optimizer.evaluate_config(config)
                print(f"评分: {score:.1f}")
            
            best_config = min(optimizer.results, key=lambda x: x['score'])['config']
            
        else:
            print("无效选择，使用随机搜索")
            best_config = optimizer.random_search(10)
        
        # 显示最佳配置
        print("\n" + "=" * 60)
        print("最佳配置")
        print("=" * 60)
        print(f"机器人数量: {best_config['num_robots']}")
        print(f"通信范围: {best_config['communication_range']}")
        print(f"世界大小: {best_config['world_size']}")
        print(f"生成范围: {best_config['spawn_range']}")
        print(f"最佳评分: {optimizer.best_score:.1f}")
        
        # 分析参数影响
        optimizer.analyze_parameter_impact()
        
        # 保存结果
        csv_file = optimizer.save_optimization_results()
        
        # 显示高成功率配置
        high_success_configs = optimizer.find_high_success_configs()
        if high_success_configs:
            print(f"\n高成功率配置 (前5个):")
            for i, config_info in enumerate(high_success_configs[:5]):
                config = config_info['config']
                print(f"  {i+1}. 机器人={config['num_robots']}, 通信范围={config['communication_range']}, 交会时间={config_info['rendezvous_time']:.1f}")
        
        print(f"\n结果文件: {csv_file}")
        
    except KeyboardInterrupt:
        print("\n优化被用户中断")
    except Exception as e:
        print(f"优化过程中出现错误: {e}")

if __name__ == "__main__":
    main()
