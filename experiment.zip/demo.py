#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
机器人交会算法演示脚本
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from main import RobotSimulation, RobotRole

def demo_basic_simulation():
    """演示基本模拟功能"""
    print("=" * 60)
    print("机器人交会算法演示")
    print("=" * 60)
    
    # 创建模拟环境
    print("创建模拟环境...")
    sim = RobotSimulation(
        num_robots=6, 
        communication_range=15.0, 
        world_size=(120, 120)
    )
    
    print(f"OK 创建了 {len(sim.robots)} 个机器人")
    print(f"OK 通信范围: {sim.communication_range}")
    print(f"OK 世界大小: {sim.world_size}")
    print(f"OK 障碍物数量: {len(sim.obstacles)}")
    
    # 运行模拟
    print("\n开始模拟...")
    print("-" * 40)
    
    for step in range(50):
        sim.update_simulation(dt=0.5)
        
        # 每10步显示状态
        if step % 10 == 0:
            leaders = [r for r in sim.robots if r.role == RobotRole.LEADER]
            sentries = [r for r in sim.robots if r.role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY]]
            members = [r for r in sim.robots if r.role == RobotRole.MEMBER]
            explorers = [r for r in sim.robots if r.role == RobotRole.REGULAR_EXPLORER]
            
            print(f"步骤 {step:2d}: 领导者={len(leaders)}, 哨兵={len(sentries)}, 成员={len(members)}, 探索者={len(explorers)}")
            
            # 显示领导者信息
            if leaders:
                for leader in leaders:
                    print(f"  领导者 R{leader.id}: 哨兵数={len(leader.sentries)}, 成员数={len(leader.members)}")
            
            if sim.rendezvous_phase:
                print(f"  *** 交会阶段开始！交会位置: ({sim.rendezvous_location.x:.1f}, {sim.rendezvous_location.y:.1f}) ***")
                break
    
    print("\n模拟完成！")
    return sim

def demo_parameter_effects():
    """演示参数对算法的影响"""
    print("\n" + "=" * 60)
    print("参数影响演示")
    print("=" * 60)
    
    # 测试不同通信范围的影响
    communication_ranges = [10.0, 20.0, 30.0]
    
    for comm_range in communication_ranges:
        print(f"\n测试通信范围: {comm_range}")
        print("-" * 30)
        
        sim = RobotSimulation(
            num_robots=4, 
            communication_range=comm_range, 
            world_size=(100, 100)
        )
        
        # 运行20步
        for step in range(20):
            sim.update_simulation(dt=0.5)
        
        # 统计角色分布
        leaders = [r for r in sim.robots if r.role == RobotRole.LEADER]
        sentries = [r for r in sim.robots if r.role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY]]
        
        print(f"  领导者数量: {len(leaders)}")
        print(f"  哨兵数量: {len(sentries)}")
        print(f"  交会阶段: {'是' if sim.rendezvous_phase else '否'}")

def demo_algorithm_phases():
    """演示算法的不同阶段"""
    print("\n" + "=" * 60)
    print("算法阶段演示")
    print("=" * 60)
    
    sim = RobotSimulation(num_robots=8, communication_range=12.0, world_size=(150, 150))
    
    print("阶段1: 初始探索")
    for step in range(10):
        sim.update_simulation(dt=0.5)
        if step % 5 == 0:
            explorers = [r for r in sim.robots if r.role == RobotRole.REGULAR_EXPLORER]
            print(f"  步骤 {step}: {len(explorers)} 个探索者")
    
    print("\n阶段2: 角色分配")
    for step in range(15):
        sim.update_simulation(dt=0.5)
        if step % 5 == 0:
            leaders = [r for r in sim.robots if r.role == RobotRole.LEADER]
            sentries = [r for r in sim.robots if r.role in [RobotRole.PRIMARY_SENTRY, RobotRole.SECONDARY_SENTRY]]
            print(f"  步骤 {step+10}: {len(leaders)} 个领导者, {len(sentries)} 个哨兵")
    
    print("\n阶段3: 交会准备")
    for step in range(10):
        sim.update_simulation(dt=0.5)
        if sim.rendezvous_phase:
            print(f"  步骤 {step+25}: 交会阶段开始！")
            break
        if step % 3 == 0:
            leaders = [r for r in sim.robots if r.role == RobotRole.LEADER]
            print(f"  步骤 {step+25}: {len(leaders)} 个领导者继续协调")

def main():
    """主演示函数"""
    print("机器人理论交会算法演示程序")
    print("本程序将展示算法的各个阶段和功能")
    
    try:
        # 基本模拟演示
        sim = demo_basic_simulation()
        
        # 参数影响演示
        demo_parameter_effects()
        
        # 算法阶段演示
        demo_algorithm_phases()
        
        print("\n" + "=" * 60)
        print("演示完成！")
        print("要查看动画可视化，请运行: python main.py")
        print("=" * 60)
        
    except Exception as e:
        print(f"演示过程中出现错误: {e}")
        print("请检查依赖库是否正确安装")

if __name__ == "__main__":
    main()
