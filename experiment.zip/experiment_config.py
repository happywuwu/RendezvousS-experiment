#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
实验参数配置界面
"""

import json
import os
from typing import Dict, List, Tuple

class ExperimentConfigInterface:
    """实验配置界面"""
    
    def __init__(self):
        self.config_file = "experiment_config.json"
        self.default_config = {
            "机器人数量范围": [4, 12],
            "通信范围范围": [5.0, 30.0],
            "世界大小范围": [[100, 100], [300, 300]],
            "生成范围比例": [0.1, 0.9],
            "实验次数": 10,
            "最大模拟时间": 1000.0,
            "时间步长": 0.5,
            "输出目录": "experiment_results"
        }
    
    def load_config(self) -> Dict:
        """加载配置"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                print(f"已加载配置文件: {self.config_file}")
                return config
            except Exception as e:
                print(f"加载配置文件失败: {e}")
                print("使用默认配置")
        else:
            print("配置文件不存在，使用默认配置")
        
        return self.default_config.copy()
    
    def save_config(self, config: Dict):
        """保存配置"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            print(f"配置已保存到: {self.config_file}")
        except Exception as e:
            print(f"保存配置失败: {e}")
    
    def interactive_config(self) -> Dict:
        """交互式配置"""
        print("=" * 60)
        print("机器人交会算法实验参数配置")
        print("=" * 60)
        
        config = self.load_config()
        
        print("\n当前配置:")
        for key, value in config.items():
            print(f"  {key}: {value}")
        
        print("\n是否要修改配置? (y/n): ", end="")
        if input().lower() != 'y':
            return config
        
        print("\n请输入新的配置值 (直接回车保持当前值):")
        
        # 机器人数量范围
        print(f"\n1. 机器人数量范围 (当前: {config['机器人数量范围']})")
        try:
            min_robots = input(f"  最小机器人数量 [{config['机器人数量范围'][0]}]: ").strip()
            if min_robots:
                config['机器人数量范围'][0] = int(min_robots)
            
            max_robots = input(f"  最大机器人数量 [{config['机器人数量范围'][1]}]: ").strip()
            if max_robots:
                config['机器人数量范围'][1] = int(max_robots)
        except ValueError:
            print("  输入无效，保持原值")
        
        # 通信范围范围
        print(f"\n2. 通信范围范围 (当前: {config['通信范围范围']})")
        try:
            min_comm = input(f"  最小通信范围 [{config['通信范围范围'][0]}]: ").strip()
            if min_comm:
                config['通信范围范围'][0] = float(min_comm)
            
            max_comm = input(f"  最大通信范围 [{config['通信范围范围'][1]}]: ").strip()
            if max_comm:
                config['通信范围范围'][1] = float(max_comm)
        except ValueError:
            print("  输入无效，保持原值")
        
        # 世界大小范围
        print(f"\n3. 世界大小范围 (当前: {config['世界大小范围']})")
        try:
            min_world = input(f"  最小世界大小 [{config['世界大小范围'][0]}]: ").strip()
            if min_world:
                config['世界大小范围'][0] = [int(x) for x in min_world.split(',')]
            
            max_world = input(f"  最大世界大小 [{config['世界大小范围'][1]}]: ").strip()
            if max_world:
                config['世界大小范围'][1] = [int(x) for x in max_world.split(',')]
        except ValueError:
            print("  输入无效，保持原值")
        
        # 生成范围比例
        print(f"\n4. 生成范围比例 (当前: {config['生成范围比例']})")
        try:
            min_ratio = input(f"  最小比例 [{config['生成范围比例'][0]}]: ").strip()
            if min_ratio:
                config['生成范围比例'][0] = float(min_ratio)
            
            max_ratio = input(f"  最大比例 [{config['生成范围比例'][1]}]: ").strip()
            if max_ratio:
                config['生成范围比例'][1] = float(max_ratio)
        except ValueError:
            print("  输入无效，保持原值")
        
        # 实验参数
        print(f"\n5. 实验参数")
        try:
            num_exp = input(f"  实验次数 [{config['实验次数']}]: ").strip()
            if num_exp:
                config['实验次数'] = int(num_exp)
            
            max_time = input(f"  最大模拟时间 [{config['最大模拟时间']}]: ").strip()
            if max_time:
                config['最大模拟时间'] = float(max_time)
            
            time_step = input(f"  时间步长 [{config['时间步长']}]: ").strip()
            if time_step:
                config['时间步长'] = float(time_step)
        except ValueError:
            print("  输入无效，保持原值")
        
        # 输出目录
        print(f"\n6. 输出设置")
        output_dir = input(f"  输出目录 [{config['输出目录']}]: ").strip()
        if output_dir:
            config['输出目录'] = output_dir
        
        return config
    
    def create_custom_experiments(self, config: Dict) -> List[Dict]:
        """根据配置创建自定义实验"""
        experiments = []
        
        print("\n创建自定义实验配置...")
        print("1. 通信范围影响实验")
        print("2. 机器人数量影响实验") 
        print("3. 世界大小影响实验")
        print("4. 综合参数实验")
        print("5. 自定义实验")
        
        choice = input("请选择实验类型 (1-5): ").strip()
        
        if choice == "1":
            # 通信范围影响实验
            comm_ranges = [5.0, 10.0, 15.0, 20.0, 25.0, 30.0]
            for comm_range in comm_ranges:
                experiments.append({
                    'num_robots': 8,
                    'communication_range': comm_range,
                    'world_size': (200, 200),
                    'spawn_range': (50, 150),
                    'max_time': config['最大模拟时间'],
                    'time_step': config['时间步长']
                })
            print(f"创建了 {len(experiments)} 个通信范围实验")
            
        elif choice == "2":
            # 机器人数量影响实验
            robot_counts = [4, 6, 8, 10, 12]
            for num_robots in robot_counts:
                experiments.append({
                    'num_robots': num_robots,
                    'communication_range': 15.0,
                    'world_size': (200, 200),
                    'spawn_range': (50, 150),
                    'max_time': config['最大模拟时间'],
                    'time_step': config['时间步长']
                })
            print(f"创建了 {len(experiments)} 个机器人数量实验")
            
        elif choice == "3":
            # 世界大小影响实验
            world_sizes = [(100, 100), (150, 150), (200, 200), (250, 250), (300, 300)]
            for world_size in world_sizes:
                experiments.append({
                    'num_robots': 8,
                    'communication_range': 15.0,
                    'world_size': world_size,
                    'spawn_range': (world_size[0] * 0.25, world_size[0] * 0.75),
                    'max_time': config['最大模拟时间'],
                    'time_step': config['时间步长']
                })
            print(f"创建了 {len(experiments)} 个世界大小实验")
            
        elif choice == "4":
            # 综合参数实验
            robot_counts = [4, 6, 8, 10]
            comm_ranges = [10.0, 15.0, 20.0, 25.0]
            for num_robots in robot_counts:
                for comm_range in comm_ranges:
                    experiments.append({
                        'num_robots': num_robots,
                        'communication_range': comm_range,
                        'world_size': (200, 200),
                        'spawn_range': (50, 150),
                        'max_time': config['最大模拟时间'],
                        'time_step': config['时间步长']
                    })
            print(f"创建了 {len(experiments)} 个综合参数实验")
            
        elif choice == "5":
            # 自定义实验
            print("请输入自定义实验参数:")
            try:
                num_custom = int(input("实验数量: "))
                for i in range(num_custom):
                    print(f"\n实验 {i+1}:")
                    num_robots = int(input("  机器人数量: "))
                    comm_range = float(input("  通信范围: "))
                    world_x = int(input("  世界宽度: "))
                    world_y = int(input("  世界高度: "))
                    spawn_min = float(input("  生成范围最小值: "))
                    spawn_max = float(input("  生成范围最大值: "))
                    
                    experiments.append({
                        'num_robots': num_robots,
                        'communication_range': comm_range,
                        'world_size': (world_x, world_y),
                        'spawn_range': (spawn_min, spawn_max),
                        'max_time': config['最大模拟时间'],
                        'time_step': config['时间步长']
                    })
                print(f"创建了 {len(experiments)} 个自定义实验")
            except ValueError:
                print("输入无效，使用默认实验")
                experiments = self.create_default_experiments(config)
        else:
            print("无效选择，使用默认实验")
            experiments = self.create_default_experiments(config)
        
        return experiments
    
    def create_default_experiments(self, config: Dict) -> List[Dict]:
        """创建默认实验配置"""
        experiments = []
        
        # 基础实验
        experiments.append({
            'num_robots': 6,
            'communication_range': 15.0,
            'world_size': (200, 200),
            'spawn_range': (50, 150),
            'max_time': config['最大模拟时间'],
            'time_step': config['时间步长']
        })
        
        return experiments

def main():
    """主函数"""
    interface = ExperimentConfigInterface()
    
    print("机器人交会算法实验配置工具")
    print("=" * 60)
    
    # 交互式配置
    config = interface.interactive_config()
    
    # 保存配置
    interface.save_config(config)
    
    # 创建实验
    print("\n是否要创建自定义实验? (y/n): ", end="")
    if input().lower() == 'y':
        experiments = interface.create_custom_experiments(config)
        
        # 保存实验配置
        exp_config_file = "custom_experiments.json"
        with open(exp_config_file, 'w', encoding='utf-8') as f:
            json.dump(experiments, f, indent=2, ensure_ascii=False)
        print(f"自定义实验配置已保存到: {exp_config_file}")
    
    print("\n配置完成！")
    print("现在可以运行: python experiment_manager.py")

if __name__ == "__main__":
    main()
