#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动化运行论文实验
"""

from paper_experiment import PaperExperiment

def main():
    """主函数"""
    print("开始自动化论文实验...")
    print("运行Figure 3(A)和Figure 3(B)的完整实验")
    print("=" * 60)
    
    experiment = PaperExperiment()
    
    # 运行所有实验
    results = experiment.run_all_experiments()
    
    print("\n实验完成！")
    print(f"总共运行了 {len(results)} 个实验")
    
    # 统计结果
    successful = sum(1 for r in results if r['success'])
    print(f"成功实验: {successful}/{len(results)} ({successful/len(results)*100:.1f}%)")
    
    if successful > 0:
        successful_results = [r for r in results if r['success']]
        avg_distance = sum(r['total_travel_distance'] for r in successful_results) / len(successful_results)
        print(f"平均总移动距离: {avg_distance:.1f}")
    
    print("\n现在可以运行数据分析:")
    print("python analyze_paper_results.py")

if __name__ == "__main__":
    main()
